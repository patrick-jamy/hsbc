/**
 * 
 * 
 * 
 * @version 1.0
 *
 * @author Patrick JAMY
 */

package exercise4.service;

public interface StatisticSubscriber {
    void onStatisticsUpdated(Statistics stats); // Call the method to update statistics
}