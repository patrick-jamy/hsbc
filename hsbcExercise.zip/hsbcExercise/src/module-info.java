/**
 * 
 */
/**
 * 
 */
module hsbcExercise {
}