Exercise 1 (ProbabilisticRandomGen), time spent to implement : ~1h30
Exercise 2 (Event Bus), time spent to implement : ~2h 
Exercise 3 (Throttler), time spent to implement : ~1h
Exercise 4 (Statistics), time spent to implement : ~1h

Each exercise is associated with different packages; each one has a "test" package where we can run some java tests classes directly in the java console (I haven't used junit because of no-library constraint)

I tried to minimize the code written to optimize  readibility / maintanability (without forget the importance of performance as wished!)

Thank you

Patrick JAMY